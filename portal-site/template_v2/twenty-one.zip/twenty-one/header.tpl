{assign var=ztClientShell value=false}
{if $loggedin && !$inShoppingCart}
    {assign var=ztClientShell value=true}
{/if}
<!doctype html>
<html lang="en">
<head>
    <meta charset="{$charset}" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>{if $kbarticle.title}{$kbarticle.title} - {/if}{$pagetitle} - {$companyname}</title>
    {include file="$template/includes/head.tpl"}
    {$headoutput}
</head>
<body class="primary-bg-color{if $ztClientShell} zt-client-shell-page{/if}" data-phone-cc-input="{$phoneNumberInputStyle}">
    {if $captcha}{$captcha->getMarkup()}{/if}
    {$headeroutput}

    <header id="header" class="header">
        {if $loggedin && !$ztClientShell}
            <div class="topbar">
                <div class="container">
                    <div class="d-flex">
                        <div class="mr-auto">
                            <button type="button" class="btn" data-toggle="popover" id="accountNotifications" data-placement="bottom">
                                <i class="far fa-flag"></i>
                                {if count($clientAlerts) > 0}
                                    {count($clientAlerts)}
                                    <span class="d-none d-sm-inline">{lang key='notifications'}</span>
                                {else}
                                    <span class="d-sm-none">0</span>
                                    <span class="d-none d-sm-inline">{lang key='nonotifications'}</span>
                                {/if}
                            </button>
                            <div id="accountNotificationsContent" class="w-hidden">
                                <ul class="client-alerts">
                                {foreach $clientAlerts as $alert}
                                    <li>
                                        <a href="{$alert->getLink()}">
                                            <i class="fas fa-fw fa-{if $alert->getSeverity() == 'danger'}exclamation-circle{elseif $alert->getSeverity() == 'warning'}exclamation-triangle{elseif $alert->getSeverity() == 'info'}info-circle{else}check-circle{/if}"></i>
                                            <div class="message">{$alert->getMessage()}</div>
                                        </a>
                                    </li>
                                {foreachelse}
                                    <li class="none">
                                        {lang key='notificationsnone'}
                                    </li>
                                {/foreach}
                                </ul>
                            </div>
                        </div>

                        <div class="ml-auto">
                            <div class="input-group active-client" role="group">
                                <div class="input-group-prepend d-none d-md-inline">
                                    <span class="input-group-text">{lang key='loggedInAs'}:</span>
                                </div>
                                <div class="btn-group">
                                    <a href="{$WEB_ROOT}/clientarea.php?action=details" class="btn btn-active-client">
                                        <span>
                                            {if $client.companyname}
                                                {$client.companyname}
                                            {else}
                                                {$client.fullName}
                                            {/if}
                                        </span>
                                    </a>
                                    <a href="{routePath('user-accounts')}" class="btn" data-toggle="tooltip" data-placement="bottom" title="Switch Account">
                                        <i class="fad fa-random"></i>
                                    </a>
                                    {if $adminMasqueradingAsClient || $adminLoggedIn}
                                        <a href="{$WEB_ROOT}/logout.php?returntoadmin=1" class="btn btn-return-to-admin" data-toggle="tooltip" data-placement="bottom" title="{if $adminMasqueradingAsClient}{lang key='adminmasqueradingasclient'} {lang key='logoutandreturntoadminarea'}{else}{lang key='adminloggedin'} {lang key='returntoadminarea'}{/if}">
                                            <i class="fas fa-redo-alt"></i>
                                            <span class="d-none d-md-inline-block">{lang key="admin.returnToAdmin"}</span>
                                        </a>
                                    {/if}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        {/if}

        <div class="navbar navbar-light">
            <div class="container">
                <a class="navbar-brand mr-3" href="{$WEB_ROOT}/index.php">
                    {if $assetLogoPath}
                        <img src="{$assetLogoPath}" alt="{$companyname}" class="logo-img">
                    {else}
                        {$companyname}
                    {/if}
                </a>

                <form method="post" action="{routePath('knowledgebase-search')}" class="form-inline ml-auto">
                    <div class="input-group search d-none d-xl-flex">
                        <div class="input-group-prepend">
                            <button class="btn btn-default" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                        <input class="form-control appended-form-control font-weight-light" type="text" name="search" placeholder="{lang key="searchOurKnowledgebase"}...">
                    </div>
                </form>

                <ul class="navbar-nav toolbar">
                    <li class="nav-item ml-3">
                        <a class="btn nav-link cart-btn" href="{$WEB_ROOT}/cart.php?a=view">
                            <i class="far fa-shopping-cart fa-fw"></i>
                            <span id="cartItemCount" class="badge badge-info">{$cartitemcount}</span>
                            <span class="sr-only">{lang key="carttitle"}</span>
                        </a>
                    </li>
                    <li class="nav-item ml-3 d-xl-none">
                        <button class="btn nav-link" type="button" data-toggle="collapse" data-target="#mainNavbar">
                            <span class="fas fa-bars fa-fw"></span>
                        </button>
                    </li>
                </ul>
            </div>
        </div>
        <div class="navbar navbar-expand-xl main-navbar-wrapper">
            <div class="container">
                <div class="collapse navbar-collapse" id="mainNavbar">
                    <form method="post" action="{routePath('knowledgebase-search')}" class="d-xl-none">
                        <div class="input-group search w-100 mb-2">
                            <div class="input-group-prepend">
                                <button class="btn btn-default" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                            <input class="form-control prepended-form-control" type="text" name="search" placeholder="{lang key="searchOurKnowledgebase"}...">
                        </div>
                    </form>
                    <ul id="nav" class="navbar-nav mr-auto">
                        {include file="$template/includes/navbar.tpl" navbar=$primaryNavbar}
                    </ul>
                    <ul class="navbar-nav ml-auto">
                        {include file="$template/includes/navbar.tpl" navbar=$secondaryNavbar rightDrop=true}
                    </ul>
                </div>
            </div>
        </div>
    </header>

    {include file="$template/includes/network-issues-notifications.tpl"}

    {if !$ztClientShell}
        <nav class="master-breadcrumb" aria-label="breadcrumb">
            <div class="container">
                {include file="$template/includes/breadcrumb.tpl"}
            </div>
        </nav>
    {/if}

    {include file="$template/includes/validateuser.tpl"}
    {include file="$template/includes/verifyemail.tpl"}

    <section id="main-body"{if $ztClientShell} class="zt-client-workspace"{/if}>
        {if $ztClientShell}
            <div class="zt-shell-backdrop" data-zt-shell-close></div>
            <div class="zt-client-shell">
                <aside class="zt-client-sidebar" aria-label="Client workspace navigation">
                    <div class="zt-shell-brand">
                        <a class="zt-shell-logo" href="{$WEB_ROOT}/clientarea.php" aria-label="{$companyname}">
                            {if $assetLogoPath}
                                <img src="{$assetLogoPath}" alt="{$companyname}">
                            {else}
                                <span>{$companyname}</span>
                            {/if}
                        </a>
                        <button class="zt-shell-icon-btn zt-shell-mobile-close" type="button" data-zt-shell-close aria-label="Close workspace menu">
                            <i class="fas fa-times" aria-hidden="true"></i>
                        </button>
                    </div>

                    <div class="zt-support-pin-card">
                        <span class="zt-support-pin-card__label">Support PIN</span>
                        <strong class="zt-support-pin-card__value" data-zt-support-pin-value>
                            {if $ztSupportPin}{$ztSupportPin|escape:'html'}{else}Not Set{/if}
                        </strong>
                        <button class="zt-support-pin-card__copy" type="button" data-zt-copy-pin{if !$ztSupportPin} disabled{/if} data-pin="{if $ztSupportPin}{$ztSupportPin|escape:'html'}{/if}">
                            Copy PIN
                        </button>
                        <span class="zt-support-pin-card__copied" data-zt-copy-confirm aria-live="polite">Copied</span>
                    </div>

                    <nav class="zt-shell-nav" aria-label="Workspace">
                        <a class="zt-shell-nav__item{if $templatefile == 'clientareahome'} is-active{/if}" href="{$WEB_ROOT}/clientarea.php">
                            <i class="fas fa-th-large" aria-hidden="true"></i>
                            <span>Workspace</span>
                        </a>
                        <a class="zt-shell-nav__item{if $templatefile == 'clientareaproducts' || $templatefile == 'clientareaproductdetails' || $templatefile == 'clientareaproductusagebilling'} is-active{/if}" href="{$WEB_ROOT}/clientarea.php?action=services">
                            <i class="fas fa-cubes" aria-hidden="true"></i>
                            <span>My Services</span>
                        </a>
                        <a class="zt-shell-nav__item{if $templatefile == 'clientareainvoices' || $templatefile == 'invoice-payment' || $templatefile == 'clientareaaddfunds' || $templatefile == 'clientareaquotes' || $templatefile == 'viewinvoice'} is-active{/if}" href="{$WEB_ROOT}/clientarea.php?action=invoices">
                            <i class="fas fa-credit-card" aria-hidden="true"></i>
                            <span>Billing</span>
                        </a>
                        <a class="zt-shell-nav__item{if $templatefile == 'supportticketslist' || $templatefile == 'viewticket' || $templatefile == 'supportticketsubmit-stepone' || $templatefile == 'supportticketsubmit-steptwo' || $templatefile == 'supportticketsubmit-confirm'} is-active{/if}" href="{$WEB_ROOT}/supporttickets.php">
                            <i class="fas fa-life-ring" aria-hidden="true"></i>
                            <span>Support</span>
                        </a>
                        <a class="zt-shell-nav__item{if $templatefile == 'clientareadomains' || $templatefile == 'clientareadomaindetails' || $templatefile == 'clientareadomainaddons' || $templatefile == 'clientareadomaincontactinfo' || $templatefile == 'clientareadomaindns' || $templatefile == 'clientareadomainemailforwarding' || $templatefile == 'clientareadomaingetepp' || $templatefile == 'clientareadomainregisterns'} is-active{/if}" href="{$WEB_ROOT}/clientarea.php?action=domains">
                            <i class="fas fa-globe" aria-hidden="true"></i>
                            <span>Domains</span>
                        </a>
                        <a class="zt-shell-nav__item{if $templatefile == 'downloads' || $templatefile == 'downloadscat'} is-active{/if}" href="{routePath('download-index')}">
                            <i class="fas fa-download" aria-hidden="true"></i>
                            <span>Downloads</span>
                        </a>
                        <a class="zt-shell-nav__item{if $templatefile == 'announcements' || $templatefile == 'viewannouncement'} is-active{/if}" href="{routePath('announcement-index')}">
                            <i class="fas fa-bullhorn" aria-hidden="true"></i>
                            <span>Announcements</span>
                        </a>
                    </nav>

                    <a class="zt-shell-status" href="{$WEB_ROOT}/serverstatus.php">
                        <span class="zt-shell-status__dot" aria-hidden="true"></span>
                        <span>
                            <strong>System Status</strong>
                            <em>All Systems Operational</em>
                        </span>
                    </a>
                </aside>

                <div class="zt-shell-main">
                    <div class="zt-shell-topbar">
                        <div class="zt-shell-topbar__start">
                            <button class="zt-shell-icon-btn zt-shell-menu-toggle" type="button" data-zt-shell-toggle aria-label="Toggle workspace menu">
                                <i class="fas fa-bars" aria-hidden="true"></i>
                            </button>
                            <div class="zt-shell-page-title">
                                <span>Customer Workspace</span>
                                <strong>{if $pagetitle}{$pagetitle}{else}Client Area{/if}</strong>
                            </div>
                        </div>

                        <div class="zt-shell-topbar__end">
                            <div class="zt-shell-notifications" aria-label="Notifications">
                                <i class="far fa-bell" aria-hidden="true"></i>
                                <span>{count($clientAlerts)}</span>
                            </div>

                            <div class="dropdown zt-shell-profile">
                                <button class="zt-shell-profile__button" type="button" id="ztShellProfileDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <span>
                                        {if $client.companyname}
                                            {$client.companyname|escape:'html'}
                                        {else}
                                            {$client.fullName|escape:'html'}
                                        {/if}
                                    </span>
                                    <i class="fas fa-chevron-down" aria-hidden="true"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right zt-shell-profile__menu" aria-labelledby="ztShellProfileDropdown">
                                    <a class="dropdown-item" href="{$WEB_ROOT}/clientarea.php?action=details">Profile</a>
                                    <a class="dropdown-item" href="{$WEB_ROOT}/logout.php">Logout</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="zt-shell-content">
                        <div class="zt-shell-content__surface primary-content">
        {else}
            <div class="{if !$skipMainBodyContainer}container{/if}">
                <div class="row">

            {if !$inShoppingCart && !$ztClientShell && ($primarySidebar->hasChildren() || $secondarySidebar->hasChildren())}
                <div class="col-lg-4 col-xl-3">
                    <div class="sidebar">
                        {include file="$template/includes/sidebar.tpl" sidebar=$primarySidebar}
                    </div>
                    {if !$inShoppingCart && $secondarySidebar->hasChildren()}
                        <div class="d-none d-lg-block sidebar">
                            {include file="$template/includes/sidebar.tpl" sidebar=$secondarySidebar}
                        </div>
                    {/if}
                </div>
            {/if}
            <div class="{if !$inShoppingCart && !$ztClientShell && ($primarySidebar->hasChildren() || $secondarySidebar->hasChildren())}col-lg-8 col-xl-9{else}col-12{/if} primary-content">
        {/if}
