                    {if $ztClientShell}
                        </div>
                    </div>
                </div>
            </div>
        {else}
                    </div>

                    </div>
                    {if !$inShoppingCart && $secondarySidebar->hasChildren()}
                        <div class="d-lg-none sidebar sidebar-secondary">
                            {include file="$template/includes/sidebar.tpl" sidebar=$secondarySidebar}
                        </div>
                    {/if}
                <div class="clearfix"></div>
            </div>
        </div>
        {/if}
    </section>

    <footer id="footer" class="footer">
        <div class="container">
            <ul class="list-inline mb-7 text-center float-lg-right">
                {include file="$template/includes/social-accounts.tpl"}

                {if $languagechangeenabled && count($locales) > 1 || $currencies}
                    <li class="list-inline-item">
                        <button type="button" class="btn" data-toggle="modal" data-target="#modalChooseLanguage">
                            <div class="d-inline-block align-middle">
                                <div class="iti-flag {if $activeLocale.countryCode === '001'}us{else}{$activeLocale.countryCode|lower}{/if}"></div>
                            </div>
                            {$activeLocale.localisedName}
                            /
                            {$activeCurrency.prefix}
                            {$activeCurrency.code}
                        </button>
                    </li>
                {/if}
            </ul>

            <ul class="nav justify-content-center justify-content-lg-start mb-7">
                <li class="nav-item">
                    <a class="nav-link" href="{$WEB_ROOT}/contact.php">
                        {lang key='contactus'}
                    </a>
                </li>
                {if $acceptTOS}
                    <li class="nav-item">
                        <a class="nav-link" href="{$tosURL}" target="_blank">{lang key='ordertos'}</a>
                    </li>
                {/if}
            </ul>

            <p class="copyright mb-0">
                {lang key="copyrightFooterNotice" year=$date_year company=$companyname}
            </p>
        </div>
    </footer>

    <div id="fullpage-overlay" class="w-hidden">
        <div class="outer-wrapper">
            <div class="inner-wrapper">
                <img src="{$WEB_ROOT}/assets/img/overlay-spinner.svg" alt="">
                <br>
                <span class="msg"></span>
            </div>
        </div>
    </div>

    <div class="modal system-modal fade" id="modalAjax" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                        <span class="sr-only">{lang key='close'}</span>
                    </button>
                </div>
                <div class="modal-body">
                    {lang key='loading'}
                </div>
                <div class="modal-footer">
                    <div class="float-left loader">
                        <i class="fas fa-circle-notch fa-spin"></i>
                        {lang key='loading'}
                    </div>
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                        {lang key='close'}
                    </button>
                    <button type="button" class="btn btn-primary modal-submit">
                        {lang key='submit'}
                    </button>
                </div>
            </div>
        </div>
    </div>

    <form method="get" action="{$currentpagelinkback}">
        <div class="modal modal-localisation" id="modalChooseLanguage" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                        {if $languagechangeenabled && count($locales) > 1}
                            <h5 class="h5 pt-5 pb-3">{lang key='chooselanguage'}</h5>
                            <div class="row item-selector">
                                <input type="hidden" name="language" data-current="{$language}" value="{$language}" />
                                {foreach $locales as $locale}
                                    <div class="col-4">
                                        <a href="#" class="item{if $language == $locale.language} active{/if}" data-value="{$locale.language}">
                                            {$locale.localisedName}
                                        </a>
                                    </div>
                                {/foreach}
                            </div>
                        {/if}
                        {if !$loggedin && $currencies}
                            <p class="h5 pt-5 pb-3">{lang key='choosecurrency'}</p>
                            <div class="row item-selector">
                                <input type="hidden" name="currency" data-current="{$activeCurrency.id}" value="">
                                {foreach $currencies as $selectCurrency}
                                    <div class="col-4">
                                        <a href="#" class="item{if $activeCurrency.id == $selectCurrency.id} active{/if}" data-value="{$selectCurrency.id}">
                                            {$selectCurrency.prefix} {$selectCurrency.code}
                                        </a>
                                    </div>
                                {/foreach}
                            </div>
                        {/if}
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-default">{lang key='apply'}</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    {if !$loggedin && $adminLoggedIn}
        <a href="{$WEB_ROOT}/logout.php?returntoadmin=1" class="btn btn-return-to-admin" data-toggle="tooltip" data-placement="bottom" title="{if $adminMasqueradingAsClient}{lang key='adminmasqueradingasclient'} {lang key='logoutandreturntoadminarea'}{else}{lang key='adminloggedin'} {lang key='returntoadminarea'}{/if}">
            <i class="fas fa-redo-alt"></i>
            <span class="d-none d-md-inline-block">{lang key="admin.returnToAdmin"}</span>
        </a>
    {/if}

    {include file="$template/includes/generate-password.tpl"}

    {if $ztClientShell}
        <script>
            (function () {
                var body = document.body;
                var toggleButton = document.querySelector('[data-zt-shell-toggle]');
                var closeButtons = document.querySelectorAll('[data-zt-shell-close]');
                var copyButton = document.querySelector('[data-zt-copy-pin]');
                var copiedLabel = document.querySelector('[data-zt-copy-confirm]');
                var copiedTimer;

                function isMobileShell() {
                    return window.matchMedia('(max-width: 991.98px)').matches;
                }

                function closeMobileShell() {
                    body.classList.remove('zt-shell-sidebar-open');
                }

                function showCopied() {
                    if (!copiedLabel) {
                        return;
                    }

                    copiedLabel.classList.add('is-visible');
                    window.clearTimeout(copiedTimer);
                    copiedTimer = window.setTimeout(function () {
                        copiedLabel.classList.remove('is-visible');
                    }, 1800);
                }

                function fallbackCopy(value) {
                    var field = document.createElement('textarea');
                    field.value = value;
                    field.setAttribute('readonly', 'readonly');
                    field.style.position = 'fixed';
                    field.style.top = '-9999px';
                    document.body.appendChild(field);
                    field.select();
                    document.execCommand('copy');
                    document.body.removeChild(field);
                    showCopied();
                }

                if (toggleButton) {
                    toggleButton.addEventListener('click', function () {
                        if (isMobileShell()) {
                            body.classList.remove('zt-shell-sidebar-collapsed');
                            body.classList.toggle('zt-shell-sidebar-open');
                            return;
                        }

                        body.classList.toggle('zt-shell-sidebar-collapsed');
                    });
                }

                Array.prototype.forEach.call(closeButtons, function (button) {
                    button.addEventListener('click', closeMobileShell);
                });

                window.addEventListener('resize', function () {
                    if (isMobileShell()) {
                        body.classList.remove('zt-shell-sidebar-collapsed');
                    } else {
                        closeMobileShell();
                    }
                });

                if (copyButton) {
                    copyButton.addEventListener('click', function () {
                        var pin = copyButton.getAttribute('data-pin');

                        if (!pin || copyButton.disabled) {
                            return;
                        }

                        if (navigator.clipboard && navigator.clipboard.writeText) {
                            navigator.clipboard.writeText(pin).then(showCopied, function () {
                                fallbackCopy(pin);
                            });
                            return;
                        }

                        fallbackCopy(pin);
                    });
                }
            }());
        </script>
    {/if}

    {$footeroutput}

</body>
</html>
