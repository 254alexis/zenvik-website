<!doctype html>
<html lang="en">
<head>
    <meta charset="{$charset}" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>{if $kbarticle.title}{$kbarticle.title} - {/if}{$pagetitle} - {$companyname}</title>
    {include file="$template/includes/head.tpl"}
    {$headoutput}
</head>
<body class="primary-bg-color" data-phone-cc-input="{$phoneNumberInputStyle}">
    {if $captcha}{$captcha->getMarkup()}{/if}
    {$headeroutput}

    <header id="header" class="header zt-header">
        {if $loggedin}
            <div class="topbar zt-client-bar">
                <div class="container zt-client-bar-inner">
                    <div class="zt-client-alerts">
                        <button type="button" class="btn zt-notification-btn" data-toggle="popover" id="accountNotifications" data-placement="bottom">
                            <i class="far fa-flag"></i>
                            {if count($clientAlerts) > 0}
                                <span class="zt-notification-count">{count($clientAlerts)}</span>
                                <span class="d-none d-sm-inline">{lang key='notifications'}</span>
                            {else}
                                <span class="d-sm-none zt-notification-count">0</span>
                                <span class="d-none d-sm-inline">{lang key='nonotifications'}</span>
                            {/if}
                        </button>
                        <div id="accountNotificationsContent" class="w-hidden">
                            <ul class="client-alerts">
                            {foreach $clientAlerts as $alert}
                                <li>
                                    <a href="{$alert->getLink()}">
                                        <i class="fas fa-fw fa-{if $alert->getSeverity() == 'danger'}exclamation-circle{elseif $alert->getSeverity() == 'warning'}exclamation-triangle{elseif $alert->getSeverity() == 'info'}info-circle{else}check-circle{/if}"></i>
                                        <div class="message">{$alert->getMessage()}</div>
                                    </a>
                                </li>
                            {foreachelse}
                                <li class="none">
                                    {lang key='notificationsnone'}
                                </li>
                            {/foreach}
                            </ul>
                        </div>
                    </div>

                    <div class="input-group active-client zt-active-client" role="group">
                        <div class="input-group-prepend d-none d-md-inline">
                            <span class="input-group-text">{lang key='loggedInAs'}:</span>
                        </div>
                        <div class="btn-group">
                            <a href="{$WEB_ROOT}/clientarea.php?action=details" class="btn btn-active-client">
                                <span>
                                    {if $client.companyname}
                                        {$client.companyname}
                                    {else}
                                        {$client.fullName}
                                    {/if}
                                </span>
                            </a>
                            <a href="{routePath('user-accounts')}" class="btn" data-toggle="tooltip" data-placement="bottom" title="Switch Account">
                                <i class="fad fa-random"></i>
                            </a>
                            {if $adminMasqueradingAsClient || $adminLoggedIn}
                                <a href="{$WEB_ROOT}/logout.php?returntoadmin=1" class="btn btn-return-to-admin" data-toggle="tooltip" data-placement="bottom" title="{if $adminMasqueradingAsClient}{lang key='adminmasqueradingasclient'} {lang key='logoutandreturntoadminarea'}{else}{lang key='adminloggedin'} {lang key='returntoadminarea'}{/if}">
                                    <i class="fas fa-redo-alt"></i>
                                    <span class="d-none d-md-inline-block">{lang key="admin.returnToAdmin"}</span>
                                </a>
                            {/if}
                        </div>
                    </div>
                </div>
            </div>
        {/if}

        <div class="zt-navbar">
            <div class="container zt-navbar-inner">
                <a class="navbar-brand zt-brand" href="{$WEB_ROOT}/index.php">
                    <img src="{$WEB_ROOT}/templates/{$template}/img/logo.png" alt="{$companyname}" class="zt-logo-img">
                    <span class="zt-brand-fallback">{$companyname}</span>
                </a>

                <button class="btn zt-menu-button d-xl-none" type="button" data-toggle="collapse" data-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="fas fa-bars fa-fw"></span>
                </button>

                <div class="collapse navbar-collapse zt-navbar-collapse zt-main-navigation" id="mainNavbar" aria-label="Main navigation">
                    <form method="post" action="{routePath('knowledgebase-search')}" class="zt-mobile-search d-xl-none">
                        <div class="input-group search w-100 mb-2">
                            <div class="input-group-prepend">
                                <button class="btn btn-default" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                            <input class="form-control prepended-form-control" type="text" name="search" placeholder="{lang key="searchOurKnowledgebase"}...">
                        </div>
                    </form>

                    <ul id="nav" class="navbar-nav zt-primary-nav">
                        {include file="$template/includes/navbar.tpl" navbar=$primaryNavbar}
                    </ul>

                    <div class="zt-header-actions">
                        {if $languagechangeenabled && count($locales) > 1 || $currencies}
                            <button type="button" class="btn zt-localisation-btn" data-toggle="modal" data-target="#modalChooseLanguage">
                                <span class="zt-flag-wrap">
                                    <span class="iti-flag {if $activeLocale.countryCode === '001'}us{else}{$activeLocale.countryCode|lower}{/if}"></span>
                                </span>
                                <span class="zt-localisation-text">{$activeLocale.localisedName}{if $currencies} / {$activeCurrency.prefix}{$activeCurrency.code}{/if}</span>
                            </button>
                        {/if}

                        <a class="zt-cart-btn" href="{$WEB_ROOT}/cart.php?a=view" aria-label="{lang key="carttitle"}">
                            <i class="far fa-shopping-cart fa-fw"></i>
                            <span id="cartItemCount" class="zt-cart-count">{$cartitemcount}</span>
                        </a>

                        <ul class="navbar-nav zt-account-menu">
                            {include file="$template/includes/navbar.tpl" navbar=$secondaryNavbar rightDrop=true}
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="zt-header-search">
            <div class="container">
                <form method="post" action="{routePath('knowledgebase-search')}" class="form-inline zt-desktop-search-form">
                    <div class="input-group search">
                        <div class="input-group-prepend">
                            <button class="btn btn-default" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                        <input class="form-control appended-form-control font-weight-light" type="text" name="search" placeholder="{lang key="searchOurKnowledgebase"}...">
                    </div>
                </form>
            </div>
        </div>
    </header>

    {include file="$template/includes/network-issues-notifications.tpl"}

    <nav class="master-breadcrumb" aria-label="breadcrumb">
        <div class="container">
            {include file="$template/includes/breadcrumb.tpl"}
        </div>
    </nav>

    {include file="$template/includes/validateuser.tpl"}
    {include file="$template/includes/verifyemail.tpl"}

    {if $templatefile == 'homepage'}
        {if $registerdomainenabled || $transferdomainenabled}
            {include file="$template/includes/domain-search.tpl"}
        {/if}
    {/if}

    <section id="main-body">
        <div class="{if !$skipMainBodyContainer}container{/if}">
            <div class="row">

            {if !$inShoppingCart && ($primarySidebar->hasChildren() || $secondarySidebar->hasChildren())}
                <div class="col-lg-4 col-xl-3">
                    <div class="sidebar">
                        {include file="$template/includes/sidebar.tpl" sidebar=$primarySidebar}
                    </div>
                    {if !$inShoppingCart && $secondarySidebar->hasChildren()}
                        <div class="d-none d-lg-block sidebar">
                            {include file="$template/includes/sidebar.tpl" sidebar=$secondarySidebar}
                        </div>
                    {/if}
                </div>
            {/if}
            <div class="{if !$inShoppingCart && ($primarySidebar->hasChildren() || $secondarySidebar->hasChildren())}col-lg-8 col-xl-9{else}col-12{/if} primary-content">
